package accumulateToStringOutput;

public class Person {
	private Name name;
	private Date dob;
	public Name getName() {
		return name;
	}
	public void setName(Name name) {
		this.name = name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Person(Name name, Date dob) {
		super();
		setName(name);
		setDob(dob);
	}
	
	public String toString() {
		return name.toString()+", born "+dob.toString();
	}
	
}
