package accumulateToStringOutput;

public class Client {

	public static void main(String[] args) {
		CustomerList c = new CustomerList();
		c.add(new Person(new Name("vanessa rosa subandi"), new Date(1,1,1995)));
		c.add(new Person(new Name("tofayel"), new Date(2,3,1996)));
		c.add(new Person(new Name("danyyil kucherenko"), new Date(34,2,1994)));
		System.out.println(c);
	}

}
