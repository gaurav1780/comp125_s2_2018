package accumulateToStringOutput;

import java.util.ArrayList;

public class CustomerList {
	private ArrayList<Person> customers;
	
	public CustomerList() {
		customers = new ArrayList();
	}
	
	public void add(Person p) {
		customers.add(p);
	}
	
	public String toString() {
		String result = "";
		for(Person person: customers) {
			result = result + person.toString() + "\n";
		}
		return result;
	}
}
