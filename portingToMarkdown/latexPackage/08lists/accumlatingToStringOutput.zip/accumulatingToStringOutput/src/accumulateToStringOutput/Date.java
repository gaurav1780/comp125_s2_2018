package accumulateToStringOutput;

public class Date {
	private int day, month, year;

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		int[] days = {0, 31, 0, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
		if(month == 2) {
			if(year%400==0 || (year%4==0 && year%100 !=0)) {
				this.day = Math.max(1, Math.min(29, day));
			}
			else {
				this.day = Math.max(1, Math.min(28, day));
			}
		}
		else {
			this.day = Math.max(1, Math.min(days[month], day));
		}
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = Math.max(1, Math.min(12, month));
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public Date(int day, int month, int year) {
		super();
		setMonth(month);
		setYear(year);
		setDay(day);
	}

	public String toString() {
		return day+"/"+month+"/"+year;
	}


}
