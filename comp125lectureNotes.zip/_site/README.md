COMP125
==========

COMP125 teaching material. Lectures include examples, exercises and short videos to help students stay on top of things.
